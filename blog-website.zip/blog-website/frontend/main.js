document.addEventListener('DOMContentLoaded', function() {
    const postForm = document.getElementById('postForm');
    const postsContainer = document.getElementById('posts');
    const loadingSpinner = document.getElementById('loadingSpinner');
    const API_URL = 'http://localhost:3000/api/posts';
    
    postForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const title = document.getElementById('title').value;
        const content = document.getElementById('content').value;

        const isEditing = postForm.dataset.editing === 'true';
        const postId = postForm.dataset.postId;

        if (isEditing) {
            fetch(`${API_URL}/${postId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ title, content })
            })
            .then(response => response.json())
            .then(() => {
                loadPosts();
                postForm.reset();
                postForm.dataset.editing = 'false';
                postForm.dataset.postId = '';
            })
            .catch(error => showError('Error editing post:', error));
        } else {
            fetch(API_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ title, content })
            })
            .then(response => response.json())
            .then(post => {
                displayPost(post);
                postForm.reset();
            })
            .catch(error => showError('Error creating post:', error));
        }
    });

    function loadPosts() {
        loadingSpinner.style.display = 'block';
        fetch(API_URL)
            .then(response => response.json())
            .then(posts => {
                postsContainer.innerHTML = '';
                posts.forEach(post => displayPost(post));
                loadingSpinner.style.display = 'none';
            })
            .catch(error => {
                showError('Error loading posts:', error);
                loadingSpinner.style.display = 'none';
            });
    }

    function displayPost(post) {
        const postElement = document.createElement('div');
        postElement.className = 'post';
        postElement.dataset.id = post.id;
        postElement.innerHTML = `
            <h2>${post.title}</h2>
            <p>${post.content}</p>
            <button class="editBtn">Edit</button>
            <button class="deleteBtn">Delete</button>
        `;
        postsContainer.appendChild(postElement);

        // Attach event listeners to the buttons
        const editBtn = postElement.querySelector('.editBtn');
        const deleteBtn = postElement.querySelector('.deleteBtn');
        
        editBtn.addEventListener('click', function() {
            editPost(post.id);
        });

        deleteBtn.addEventListener('click', function() {
            deletePost(post.id);
        });
    }

    function showError(message, error) {
        const errorElement = document.createElement('div');
        errorElement.className = 'error';
        errorElement.textContent = `${message} ${error.message}`;
        document.body.appendChild(errorElement);
        setTimeout(() => errorElement.remove(), 5000);
    }

    function deletePost(id) {
        fetch(`${API_URL}/${id}`, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(() => loadPosts())
        .catch(error => showError('Error deleting post:', error));
    }

    function editPost(id) {
        const postElement = document.querySelector(`.post[data-id="${id}"]`);
        const title = postElement.querySelector('h2').textContent;
        const content = postElement.querySelector('p').textContent;

        postForm.title.value = title;
        postForm.content.value = content;
        postForm.dataset.editing = 'true';
        postForm.dataset.postId = id;
    }

    loadPosts();
});
